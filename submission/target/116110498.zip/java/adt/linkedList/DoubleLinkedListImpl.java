package adt.linkedList;

public class DoubleLinkedListImpl<T> extends SingleLinkedListImpl<T> implements DoubleLinkedList<T> {

   protected DoubleLinkedListNode<T> last;

   public DoubleLinkedListImpl() {
      this.head = new DoubleLinkedListNode<T>();
      this.last = new DoubleLinkedListNode<T>();
   }

   @Override
   public void insertFirst(T element) {
      if (this.head.isNIL()) {
         this.head.setData(element);
         this.last.setData(element);
      } else {
         DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<T>();
         newNode.setData(element);
         newNode.setNext(head);
         DoubleLinkedListNode h = (DoubleLinkedListNode) head;
         h.setPrevious(newNode);
         newNode.setPrevious(null);
         head = newNode;
      }
   }

   @Override
   public void removeFirst() {
      if (this.isEmpty())
         return;
      if (head.equals(last)) {
    	 last.setData(null);
         head.setData(null);
      } else {
    	  DoubleLinkedListNode newHead = (DoubleLinkedListNode)head.getNext();
    	  newHead.setPrevious(null);
    	  head = newHead;
      }
   }

   @Override
   public void removeLast() {
	   if (last.getPrevious() == null) {
	         head.setData(null);
	      }
      DoubleLinkedListNode newLast = last.getPrevious();
      newLast.setNext(null);
      setLast(newLast);
   }

   @Override
   public boolean isEmpty() {
      if (head.isNIL()) {
         return true;
      } else {
         return false;
      }
   }

   @Override
   public int size() {
      int size = 1;
      DoubleLinkedListNode aux = (DoubleLinkedListNode) head;

      if (this.isEmpty()) {
         return 0;
      }

      while (aux.getNext() != null) {
         size++;
         aux = (DoubleLinkedListNode) aux.getNext();
      }

      return size;
   }

   @Override
   public T search(T element) {
      SingleLinkedListNode aux = head;

      while (aux.getData() != element && aux.getNext() != null) {

         aux = aux.getNext();

      }

      if (aux.getData().equals(element)) {
         return (T) aux.getData();
      } else {
         return null;
      }

   }

   @Override
   public void insert(T element) {
      if (element == null) {
         return;
      }

      if (head.getData() == null) {
         head.setData(element);
         return;
      }

      DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<T>(element, null, null);

      DoubleLinkedListNode aux = (DoubleLinkedListNode) head;

      while (aux.getNext() != null) {
         aux = (DoubleLinkedListNode) aux.getNext();
      }

      aux.setNext(newNode);

      newNode.setPrevious(aux);

      setLast(newNode);

   }

   @Override
   public void remove(T element) {
      if (this.isEmpty()) {
         return;
      }

      DoubleLinkedListNode aux = (DoubleLinkedListNode)this.head;

      while (!aux.isNIL() && aux.getData() != element) {
         aux = (DoubleLinkedListNode) aux.getNext();
      }
      
      ((DoubleLinkedListNode<T>) aux.getNext()).setPrevious(aux.getPrevious());
      aux.getPrevious().setNext(aux.getNext());

   }

   @Override
   public T[] toArray() {
      T[] array = (T[]) new Object[this.size()];
      int index = 0;
      SingleLinkedListNode aux = this.head;

      while (index < this.size() && aux.getData() != null) {

         array[index++] = (T) aux.getData();
         aux = aux.getNext();
      }
      return array;
   }

   public DoubleLinkedListNode<T> getLast() {
      return last;
   }

   public void setLast(DoubleLinkedListNode<T> last) {
      this.last = last;
   }

}
