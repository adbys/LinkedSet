package adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T> {

   protected SingleLinkedListNode<T> head;

   public SingleLinkedListImpl() {
      this.head = new SingleLinkedListNode<T>();
   }

   @Override
   public boolean isEmpty() {
      if (head.getData() == null) {
         return true;
      } else {
         return false;
      }
   }

   @Override
   public int size() {
      int size = 1;
      SingleLinkedListNode aux = head;

      if (this.isEmpty()) {
         return 0;
      }

      while (aux.getNext() != null) {
         aux = aux.getNext();
         size++;
      }

      return size;
   }

   @Override
   public T search(T element) {
      SingleLinkedListNode aux = head;

      while (aux.getData() != element && aux.getNext() != null) {

         aux = aux.getNext();

      }

      if (aux.getData().equals(element)) {
         return (T) aux.getData();
      } else {
         return null;
      }

   }

   @Override
   public void insert(T element) {
      if (element == null) {
         return;
      }

      if (head.getData() == null) {
         head.setData(element);
         return;
      }

      SingleLinkedListNode<T> newNode = new SingleLinkedListNode<T>(element, null);

      SingleLinkedListNode aux = head;

      while (aux.getNext() != null) {
         aux = aux.getNext();
      }

      aux.setNext(newNode);

   }

   @Override
   public void remove(T element) {
      if (this.isEmpty()) {
         return;
      }

      SingleLinkedListNode previous = null;
      SingleLinkedListNode aux = this.head;

      while (!aux.isNIL() && aux.getData() != element) {
         previous = aux;
         aux = aux.getNext();
      }

      previous.setNext(aux.getNext());

   }

   @Override
   public T[] toArray() {
      T[] array = (T[]) new Object[this.size()];
      int index = 0;
      SingleLinkedListNode aux = this.head;

      while (index < this.size() && aux.getData() != null) {

         array[index++] = (T) aux.getData();
         aux = aux.getNext();
      }

      return array;
   }

   public SingleLinkedListNode<T> getHead() {
      return head;
   }

   public void setHead(SingleLinkedListNode<T> head) {
      this.head = head;
   }

}
